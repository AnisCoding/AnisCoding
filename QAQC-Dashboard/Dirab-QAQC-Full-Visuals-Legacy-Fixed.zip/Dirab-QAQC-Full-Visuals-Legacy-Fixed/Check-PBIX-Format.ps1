param([Parameter(Mandatory=$true)][string]$Path)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$resolved = (Resolve-Path -LiteralPath $Path).Path
$archive = [System.IO.Compression.ZipFile]::OpenRead($resolved)
try {
    $legacy = $null -ne $archive.GetEntry('Report/Layout')
    $pbir = @($archive.Entries | Where-Object { $_.FullName.StartsWith('Report/definition/') }).Count
    Write-Output "Legacy Report/Layout present: $legacy"
    Write-Output "PBIR definition entries: $pbir"
    if ($legacy -and $pbir -eq 0) {
        Write-Output 'Legacy report format confirmed. Report Server compatibility still requires an upload test.'
    } else {
        Write-Output 'The expected legacy report format was not confirmed. Do not replace the working server report.'
        exit 1
    }
} finally {
    $archive.Dispose()
}
